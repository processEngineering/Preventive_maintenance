'use strict';

const http = require('node:http');
const { Pool } = require('pg');
const { handleAuthRequest } = require('./auth');

function createServer(pool) {
  return http.createServer(async (req, res) => {
    if (await handleAuthRequest(req, res, pool)) return;

    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');

    if (req.method !== 'GET') {
      res.writeHead(405, { Allow: 'GET' });
      res.end(JSON.stringify({ error: 'Method not allowed' }));
      return;
    }

    if (req.url === '/healthz') {
      res.writeHead(200);
      res.end(JSON.stringify({ status: 'ok' }));
      return;
    }

    if (req.url === '/readyz') {
      try {
        await pool.query('SELECT 1 FROM public.profiles LIMIT 1');
        res.writeHead(200);
        res.end(JSON.stringify({ status: 'ready', database: 'connected' }));
      } catch (error) {
        console.error('Database readiness check failed:', error.message);
        res.writeHead(503);
        res.end(JSON.stringify({ status: 'unavailable' }));
      }
      return;
    }

    res.writeHead(404);
    res.end(JSON.stringify({ error: 'Not found' }));
  });
}

function validateDatabaseEnvironment(env) {
  const required = ['PGHOST', 'PGDATABASE', 'PGUSER', 'PGPASSWORD'];
  const missing = required.filter((name) => !env[name]);

  if (missing.length > 0) {
    throw new Error(`Missing required database environment variables: ${missing.join(', ')}`);
  }

  if (env.PGDATABASE !== 'mtc_migration_test2') {
    throw new Error('PGDATABASE must be mtc_migration_test2 for this connectivity proof');
  }

  const port = env.PGPORT ? Number(env.PGPORT) : 5432;
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PGPORT must be an integer between 1 and 65535');
  }

  return { port };
}

function start() {
  const { port: databasePort } = validateDatabaseEnvironment(process.env);
  const apiPort = process.env.API_PORT ? Number(process.env.API_PORT) : 3000;
  if (!Number.isInteger(apiPort) || apiPort < 1 || apiPort > 65535) {
    throw new Error('API_PORT must be an integer between 1 and 65535');
  }

  const pool = new Pool({
    host: process.env.PGHOST,
    port: databasePort,
    database: process.env.PGDATABASE,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    max: 3,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 10000
  });
  const server = createServer(pool);
  const host = process.env.API_HOST || '127.0.0.1';

  server.listen(apiPort, host, () => {
    console.log(`MTC API listening on http://${host}:${apiPort}`);
  });

  const shutdown = () => {
    server.close(async (error) => {
      if (error) {
        console.error('API shutdown failed:', error.message);
        process.exitCode = 1;
      }
      await pool.end();
    });
  };

  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
}

if (require.main === module) {
  try {
    start();
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

module.exports = { createServer, validateDatabaseEnvironment };
