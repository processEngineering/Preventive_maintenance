# MTC API authentication prototype

This is a Node.js prototype for the test-database connection, server-side
login/session design, and one-time password setup. For this test package, it serves
a limited test page and setup-password page from the sibling `public` folder.
Supabase-backed application pages are deliberately excluded. This is not a completed
application migration.

## Requirements

- Node.js 20 or later
- Network access from this machine to the PostgreSQL test database
- The restricted `mtc_api_auth_test` PostgreSQL role described below

Do not use a PostgreSQL superuser. Do not commit database credentials or place them
in this repository.

## Unit-test locally

From this directory:

```powershell
npm.cmd ci
npm.cmd test
```

The tests use a stub database client and do not connect to PostgreSQL.

## Run on PE-SERVER2

Extract the complete test package so `backend` and `public` are sibling folders.
It contains only a test notice and the password-setup page; it does not contain the
existing Supabase-backed app pages. Open PowerShell on PE-SERVER2 and run the
following from the `backend` folder:

```powershell
npm.cmd ci
npm.cmd test

$env:PGHOST = '127.0.0.1'
$env:PGPORT = '5432'
$env:PGDATABASE = 'mtc_migration_test2'
$env:PGUSER = 'mtc_api_auth_test'
$securePassword = Read-Host 'Test-only PostgreSQL password' -AsSecureString
$passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
try {
    $env:PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
}

npm.cmd start
```

Use only the limited `mtc_api_auth_test` role; never use a superuser for the API.
If PostgreSQL is not listening on `127.0.0.1:5432`, use the approved host and port
for the test instance. The app refuses to start if `PGDATABASE` is not exactly
`mtc_migration_test2`.

While `npm.cmd start` is running, open this address in a browser on PE-SERVER2:

```text
http://127.0.0.1:3000/
```

The page should say that this test site does not include the Supabase-backed app.
The password-setup page is at `/auth/setup-password.html`. The API and test pages
share the same address. To check the database from a second
PowerShell window, run `Invoke-RestMethod http://127.0.0.1:3000/readyz`; expect
`status: ready` and `database: connected`. A `503` means the API cannot complete
its database query; check the local API log and confirm the test role, database
name, host, port, and permissions. Do not paste credentials or personal data into
chat. Stop the API with Ctrl+C, then clear its environment variables:

```powershell
'PGHOST', 'PGPORT', 'PGDATABASE', 'PGUSER', 'PGPASSWORD' | ForEach-Object {
    Remove-Item "Env:$_" -ErrorAction SilentlyContinue
}
Remove-Variable securePassword, passwordPointer -ErrorAction SilentlyContinue
```

## Endpoints

- `GET /healthz` checks that the process is running.
- `GET /readyz` runs only `SELECT 1 FROM public.profiles LIMIT 1` and returns
  `{"status":"ready","database":"connected"}` on success. It returns a generic
  `503` response on connection/query failure and does not return database details.
- `GET /` and other frontend paths serve files from the sibling `public` folder.
  The test package includes only a test notice and password-setup page, not the
  existing Supabase-backed application. Directory listings and file-write routes
  are not provided.
- `POST /api/auth/login` checks a pre-provisioned, email-verified account and creates
  a seven-day server-side session. Passwords are verified using Node.js scrypt.
- `POST /api/auth/setup-password` redeems a one-time 24-hour token, sets a password,
  marks the account email verified, and creates a session in one database operation.
- `GET /api/auth/me` checks the session cookie and returns the signed-in profile.
- `POST /api/auth/logout` revokes the server-side session and clears the cookie.
- `backend/scripts/send-password-setup.js` supports a one-account pilot with
  `--send-test` and a separately guarded 22-account send with `--send-all`.
  Neither mode is ready to run until the HTTPS route and a separate,
  least-privilege provisioning role have been configured and tested.

Login uses an `HttpOnly`, `Secure`, `SameSite=Lax` cookie. Only a hash of the random
session token is stored in PostgreSQL. The `jabatan` value is returned as profile
information; it does not grant different API permissions.

## Authentication prototype limitations

- The schema in `sql/001_auth.sql` has been applied once to `mtc_migration_test2` on
  PE-SERVER2. Do not run it again there; it is not an idempotent migration.
- Existing Supabase user IDs and emails have not been imported. Keep any account
  export private; do not put it in the repository or send it in chat.
- The department Gmail sender has not been configured. Never paste its App Password
  into chat, source code, a frontend setting, or the repository.
- The setup-token schema in `sql/002_setup_tokens.sql` has been applied to
  `mtc_migration_test2`. The `mtc_api_auth_test` role has been granted the
  required setup-token and account-column permissions. No setup-token data exists.
- The limited test pages are served by the same Node.js process as the API; the
  existing Supabase-backed application pages are deliberately excluded. External
  HTTPS access has not been configured or tested; the company-approved tunnel must
  be configured and verified before any password-setup email is sent.
- No actual setup email has been sent, and no real account has been provisioned.
- The temporary provisioning role for creating `app_users` records and setup tokens
  has not been created. The mass-send mode additionally requires
  `CONFIRM_SEND_ALL=22`; the pilot mode accepts exactly one recipient and requires
  a matching `SETUP_TEST_EMAIL`.
- Signup, password reset, login rate limiting, and operational-feature authorization
  are not implemented.
- The existing frontend still uses Supabase. These endpoints do not replace it yet.
- Do not open an ngrok tunnel or expose this prototype externally until the approved
  test route and its access rules have been confirmed.

## Test-database schema and runtime account

The one-time schema migration was applied to `mtc_migration_test2` using an
administrator-controlled session. It created empty `app_users` and `app_sessions`
tables; no profile or checklist rows were changed. It must not be applied to
production.

The existing `mtc_api_connectivity` role remains read-only. The separate
`mtc_api_auth_test` runtime role has been created for the prototype and granted only:

- `CONNECT` on `mtc_migration_test2`
- `USAGE` on schema `public`
- `SELECT` on `profiles` and `app_users`
- `SELECT`, `INSERT`, and `DELETE` on `app_sessions`

The setup-token migration has been applied to `mtc_migration_test2`, and the
runtime role has been granted only the additional permissions needed to read setup
tokens, update `consumed_at`, update `password_hash` and `email_verified_at`, and
insert sessions. These permissions were checked with zero-row updates; no user data
was changed. The separate setup-email script needs a different, temporary provisioning role
that can verify profiles, create `app_users` entries, and create/delete setup tokens.
Do not use a PostgreSQL superuser for either role or put its credentials in source
control. Do not apply either migration to production.

Do not grant the API role table ownership, schema creation, or access to production.
Do not put credentials in this repository.
