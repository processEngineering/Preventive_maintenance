'use strict';

function createGmailTransport(env, nodemailer) {
  const required = ['GMAIL_ADDRESS', 'GMAIL_APP_PASSWORD'];
  const missing = required.filter((name) => !env[name]);
  if (missing.length > 0) {
    throw new Error(`Missing required email environment variables: ${missing.join(', ')}`);
  }

  return nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
      user: env.GMAIL_ADDRESS,
      pass: env.GMAIL_APP_PASSWORD.replace(/\s+/g, '')
    }
  });
}

async function sendPasswordSetupEmail({ transport, from, to, setupUrl }) {
  if (!from || !to || !setupUrl) {
    throw new Error('Sender, recipient, and setup link are required');
  }

  const parsedUrl = new URL(setupUrl);
  if (parsedUrl.protocol !== 'https:') {
    throw new Error('Password setup links must use HTTPS');
  }

  try {
    await transport.sendMail({
      from,
      to,
      subject: 'Set up your MTC account password',
      text: `Use this one-time link to set your MTC account password. It expires in 24 hours:\n\n${setupUrl}\n\nIf you did not expect this email, you can ignore it.`,
      html: `<p>Use this one-time link to set your MTC account password. It expires in 24 hours:</p><p><a href="${setupUrl}">Set up your MTC password</a></p><p>If you did not expect this email, you can ignore it.</p>`
    });
  } catch {
    throw new Error('Could not send password setup email');
  }
}

module.exports = { createGmailTransport, sendPasswordSetupEmail };
