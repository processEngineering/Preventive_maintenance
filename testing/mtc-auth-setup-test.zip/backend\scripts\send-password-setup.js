'use strict';

const { randomBytes, createHash } = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { Pool } = require('pg');
const nodemailer = require('nodemailer');
const { createGmailTransport, sendPasswordSetupEmail } = require('../email');

const EXPECTED_USERS = 22;
const SETUP_TOKEN_HOURS = 24;

function validateUsers(users) {
  if (!Array.isArray(users) || users.length !== EXPECTED_USERS) {
    throw new Error(`Input must contain exactly ${EXPECTED_USERS} users`);
  }

  const ids = new Set();
  const emails = new Set();
  for (const user of users) {
    if (
      !user || typeof user.profile_id !== 'string' ||
      !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(user.profile_id)
    ) {
      throw new Error('Every user must have a valid profile_id');
    }
    if (typeof user.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)) {
      throw new Error('Every user must have a valid email');
    }
    const id = user.profile_id.toLowerCase();
    const email = user.email.trim().toLowerCase();
    if (ids.has(id) || emails.has(email)) {
      throw new Error('Input contains duplicate profile IDs or emails');
    }
    ids.add(id);
    emails.add(email);
  }
  return users.map((user) => ({
    profile_id: user.profile_id.toLowerCase(),
    email: user.email.trim()
  }));
}

async function createSetupToken(pool, user) {
  const token = randomBytes(32).toString('base64url');
  const tokenHash = createHash('sha256').update(token).digest('hex');
  const client = await pool.connect();

  try {
    await client.query('BEGIN');
    const profile = await client.query(
      'SELECT id FROM public.profiles WHERE id = $1',
      [user.profile_id]
    );
    if (profile.rowCount !== 1) {
      throw new Error('A supplied profile ID does not exist');
    }

    await client.query(
      `INSERT INTO public.app_users (profile_id, email)
       VALUES ($1, $2)
       ON CONFLICT (profile_id) DO NOTHING`,
      [user.profile_id, user.email]
    );
    const existing = await client.query(
      `SELECT email_normalized, password_hash
       FROM public.app_users
       WHERE profile_id = $1
       FOR UPDATE`,
      [user.profile_id]
    );
    if (
      existing.rowCount !== 1 ||
      existing.rows[0].email_normalized !== user.email.toLowerCase() ||
      existing.rows[0].password_hash
    ) {
      throw new Error('Existing account does not match the supplied setup record');
    }

    await client.query(
      `DELETE FROM public.app_setup_tokens
       WHERE profile_id = $1 AND consumed_at IS NULL`,
      [user.profile_id]
    );
    await client.query(
      `INSERT INTO public.app_setup_tokens (token_hash, profile_id, expires_at)
       VALUES ($1, $2, now() + interval '24 hours')`,
      [tokenHash, user.profile_id]
    );
    await client.query('COMMIT');
    return token;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function main() {
  if (process.argv[2] !== '--send' || !process.argv[3]) {
    throw new Error('Usage: node scripts/send-password-setup.js --send <private-users.json>');
  }
  if (process.env.PGDATABASE !== 'mtc_migration_test2') {
    throw new Error('PGDATABASE must be mtc_migration_test2');
  }

  const appOrigin = process.env.PUBLIC_APP_ORIGIN;
  if (!appOrigin || new URL(appOrigin).protocol !== 'https:') {
    throw new Error('PUBLIC_APP_ORIGIN must be the HTTPS frontend origin');
  }

  const usersPath = path.resolve(process.argv[3]);
  const users = validateUsers(JSON.parse(await fs.readFile(usersPath, 'utf8')));
  const transport = createGmailTransport(process.env, nodemailer);
  await transport.verify();

  const pool = new Pool({
    host: process.env.PGHOST,
    port: Number(process.env.PGPORT || 5432),
    database: process.env.PGDATABASE,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    max: 1,
    connectionTimeoutMillis: 5000
  });

  let sent = 0;
  try {
    const profileIds = users.map((user) => user.profile_id);
    const existingProfiles = await pool.query(
      'SELECT id FROM public.profiles WHERE id = ANY($1::uuid[])',
      [profileIds]
    );
    if (existingProfiles.rowCount !== users.length) {
      throw new Error('The input profile IDs do not all match profiles in the test database');
    }

    for (const user of users) {
      const token = await createSetupToken(pool, user);
      const setupUrl = new URL('/auth/setup-password.html', appOrigin);
      setupUrl.hash = new URLSearchParams({ token }).toString();
      try {
        await sendPasswordSetupEmail({
          transport,
          from: process.env.GMAIL_ADDRESS,
          to: user.email,
          setupUrl: setupUrl.toString()
        });
        sent += 1;
      } catch (error) {
        const tokenHash = createHash('sha256').update(token).digest('hex');
        await pool.query(
          'DELETE FROM public.app_setup_tokens WHERE token_hash = $1 AND consumed_at IS NULL',
          [tokenHash]
        );
        throw error;
      }
    }
    console.log(`Sent ${sent} password setup emails.`);
  } finally {
    await pool.end();
    transport.close();
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}

module.exports = { validateUsers };
