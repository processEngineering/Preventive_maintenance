# MTC API authentication prototype

This is a Node.js prototype for the test-database connection, server-side
login/session design, and one-time password setup. The latest password-setup and
email changes have passed local unit tests, but have not been installed on
PE-SERVER2, connected to the frontend, or tested with a real email. Do not expose
the prototype to the internet or use it for production traffic.

## Requirements

- Node.js 20 or later
- Network access from this machine to the PostgreSQL test database
- The restricted `mtc_api_auth_test` PostgreSQL role described below

Do not use a PostgreSQL superuser. Do not commit database credentials or place them
in this repository.

## Unit-test locally

From this directory:

```powershell
npm.cmd ci
npm.cmd test
```

The tests use a stub database client and do not connect to PostgreSQL.

## Verify database connectivity on PE-SERVER2

The prototype has been copied to `C:\Apps\mtc-backend-auth-20261026` on PE-SERVER2.
For a fresh copy, use an approved transfer method. Open PowerShell on PE-SERVER2 and
run the following from that directory:

```powershell
npm.cmd ci
npm.cmd test

$env:PGHOST = '127.0.0.1'
$env:PGPORT = '5432'
$env:PGDATABASE = 'mtc_migration_test2'
$env:PGUSER = 'mtc_api_auth_test'
$securePassword = Read-Host 'Test-only PostgreSQL password' -AsSecureString
$passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
try {
    $env:PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
}

npm.cmd start
```

Use only the limited `mtc_api_auth_test` role; never use a superuser for the API.
If PostgreSQL is not listening on `127.0.0.1:5432`, use the approved host and port
for the test instance. The app refuses to start if `PGDATABASE` is not exactly
`mtc_migration_test2`.

While `npm.cmd start` is running, open a second PowerShell window on PE-SERVER2 and run:

```powershell
Invoke-RestMethod http://127.0.0.1:3000/healthz
Invoke-RestMethod http://127.0.0.1:3000/readyz
```

Expect `healthz` to return `status: ok` and `readyz` to return `status: ready` with
`database: connected`. A `503` from `readyz` means the API process is running but
cannot complete its database query; check the local API log and confirm the test
role, database name, host, port, and table permission. Do not paste credentials or
personal data into chat. Stop the API with Ctrl+C in the first window, then clear its
environment variables with:

```powershell
'PGHOST', 'PGPORT', 'PGDATABASE', 'PGUSER', 'PGPASSWORD' | ForEach-Object {
    Remove-Item "Env:$_" -ErrorAction SilentlyContinue
}
Remove-Variable securePassword, passwordPointer -ErrorAction SilentlyContinue
```

## Endpoints

- `GET /healthz` checks that the process is running.
- `GET /readyz` runs only `SELECT 1 FROM public.profiles LIMIT 1` and returns
  `{"status":"ready","database":"connected"}` on success. It returns a generic
  `503` response on connection/query failure and does not return database details.
- `POST /api/auth/login` checks a pre-provisioned, email-verified account and creates
  a seven-day server-side session. Passwords are verified using Node.js scrypt.
- `POST /api/auth/setup-password` redeems a one-time 24-hour token, sets a password,
  marks the account email verified, and creates a session in one database operation.
- `GET /api/auth/me` checks the session cookie and returns the signed-in profile.
- `POST /api/auth/logout` revokes the server-side session and clears the cookie.
- `backend/scripts/send-password-setup.js` can provision and email setup links for
  exactly 22 mapped profiles when explicitly run with `--send`. Do not run it yet.

Login uses an `HttpOnly`, `Secure`, `SameSite=Lax` cookie. Only a hash of the random
session token is stored in PostgreSQL. The `jabatan` value is returned as profile
information; it does not grant different API permissions.

## Authentication prototype limitations

- The schema in `sql/001_auth.sql` has been applied once to `mtc_migration_test2` on
  PE-SERVER2. Do not run it again there; it is not an idempotent migration.
- Existing Supabase user IDs and emails have not been imported. Keep any account
  export private; do not put it in the repository or send it in chat.
- The department Gmail sender has not been configured. Never paste its App Password
  into chat, source code, a frontend setting, or the repository.
- The setup-token schema in `sql/002_setup_tokens.sql` has not been applied to
  PE-SERVER2. Its required least-privilege database grants have not been made.
- The frontend page and API route are not connected. The Vercel-to-API HTTPS proxy
  and approved PE-SERVER2 connectivity method must be configured and tested before
  any password-setup email is sent.
- No actual setup email has been sent, and no real account has been provisioned.
- Signup, password reset, login rate limiting, and operational-feature authorization
  are not implemented.
- The existing frontend still uses Supabase. These endpoints do not replace it yet.
- Do not open an ngrok tunnel or expose this prototype externally.

## Test-database schema and runtime account

The one-time schema migration was applied to `mtc_migration_test2` using an
administrator-controlled session. It created empty `app_users` and `app_sessions`
tables; no profile or checklist rows were changed. It must not be applied to
production.

The existing `mtc_api_connectivity` role remains read-only. The separate
`mtc_api_auth_test` runtime role has been created for the prototype and granted only:

- `CONNECT` on `mtc_migration_test2`
- `USAGE` on schema `public`
- `SELECT` on `profiles` and `app_users`
- `SELECT`, `INSERT`, and `DELETE` on `app_sessions`

Before testing password setup, an administrator must apply
`sql/002_setup_tokens.sql` to `mtc_migration_test2` only, then grant the runtime
role only the additional permissions needed to read setup tokens, update
`consumed_at`, update `password_hash` and `email_verified_at`, and insert sessions.
The separate setup-email script needs a different, temporary provisioning role
that can verify profiles, create `app_users` entries, and create/delete setup tokens.
Do not use a PostgreSQL superuser for either role or put its credentials in source
control. Do not apply either migration to production.

Do not grant the API role table ownership, schema creation, or access to production.
Do not put credentials in this repository.
