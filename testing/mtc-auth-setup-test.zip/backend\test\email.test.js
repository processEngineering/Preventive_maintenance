'use strict';

const assert = require('node:assert/strict');
const { test } = require('node:test');
const { createGmailTransport, sendPasswordSetupEmail } = require('../email');
const { validateUsers } = require('../scripts/send-password-setup');

test('Gmail SMTP config uses TLS and strips spaces in app passwords', () => {
  let options;
  const transport = createGmailTransport(
    { GMAIL_ADDRESS: 'department@example.com', GMAIL_APP_PASSWORD: 'abcd efgh ijkl mnop' },
    { createTransport: (value) => { options = value; return {}; } }
  );

  assert.deepEqual(transport, {});
  assert.equal(options.host, 'smtp.gmail.com');
  assert.equal(options.port, 465);
  assert.equal(options.secure, true);
  assert.equal(options.auth.pass, 'abcdefghijklmnop');
});

test('setup email requires HTTPS and sends a plain-text and HTML link', async () => {
  let message;
  const transport = {
    async sendMail(value) {
      message = value;
    }
  };

  await assert.rejects(
    sendPasswordSetupEmail({
      transport,
      from: 'department@example.com',
      to: 'user@example.com',
      setupUrl: 'http://example.com/setup'
    }),
    /HTTPS/
  );
  await sendPasswordSetupEmail({
    transport,
    from: 'department@example.com',
    to: 'user@example.com',
    setupUrl: 'https://example.com/auth/setup-password.html#token=abc'
  });
  assert.match(message.text, /https:\/\/example\.com\/auth\/setup-password\.html#token=abc/);
  assert.match(message.html, /href="https:\/\/example\.com\/auth\/setup-password\.html#token=abc/);
});

test('existing-account input requires exactly 22 unique profile/email pairs', () => {
  const users = Array.from({ length: 22 }, (_, index) => ({
    profile_id: `00000000-0000-0000-0000-${String(index + 1).padStart(12, '0')}`,
    email: `user${index + 1}@example.com`
  }));

  assert.equal(validateUsers(users).length, 22);
  assert.throws(() => validateUsers(users.slice(0, 21)), /exactly 22/);
  assert.throws(
    () => validateUsers([...users.slice(0, 21), { ...users[0], email: 'other@example.com' }]),
    /duplicate/
  );
});
