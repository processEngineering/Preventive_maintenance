'use strict';

const assert = require('node:assert/strict');
const { after, before, test } = require('node:test');
const { hashPassword } = require('../auth');
const { createServer, validateDatabaseEnvironment } = require('../server');

let server;
let baseUrl;
let queryError;
const queries = [];
let authUser;
const sessions = new Map();
const pool = {
  async query(sql, values = []) {
    queries.push(sql);
    if (queryError) {
      throw queryError;
    }
    if (sql.includes('FROM public.app_users u')) {
      return { rows: authUser ? [authUser] : [] };
    }
    if (sql.includes('INSERT INTO public.app_sessions')) {
      sessions.set(values[0], values[1]);
      return { rows: [] };
    }
    if (sql.includes('FROM public.app_sessions s')) {
      const profileId = sessions.get(values[0]);
      return {
        rows: profileId ? [{
          id: profileId,
          full_name: 'Test User',
          divisi: 'Testing',
          jabatan: 'OPERATOR | PELAKSANA'
        }] : []
      };
    }
    if (sql.includes('DELETE FROM public.app_sessions')) {
      sessions.delete(values[0]);
      return { rows: [] };
    }
    return { rows: [{ '?column?': 1 }] };
  }
};

before(async () => {
  authUser = {
    profile_id: '00000000-0000-0000-0000-000000000001',
    password_hash: await hashPassword('test-password-123'),
    email_verified_at: new Date(),
    full_name: 'Test User',
    divisi: 'Testing',
    jabatan: 'OPERATOR | PELAKSANA'
  };
  server = createServer(pool);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
});

test('health endpoint reports process status without querying the database', async () => {
  const response = await fetch(`${baseUrl}/healthz`);

  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { status: 'ok' });
  assert.equal(queries.length, 0);
});

test('readiness endpoint performs only the intended profiles existence query', async () => {
  const response = await fetch(`${baseUrl}/readyz`);

  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { status: 'ready', database: 'connected' });
  assert.equal(queries.at(-1), 'SELECT 1 FROM public.profiles LIMIT 1');
});

test('readiness endpoint does not expose database errors', async () => {
  queryError = new Error('internal database detail');
  const response = await fetch(`${baseUrl}/readyz`);
  queryError = undefined;

  assert.equal(response.status, 503);
  assert.deepEqual(await response.json(), { status: 'unavailable' });
});

test('only GET requests are accepted', async () => {
  const response = await fetch(`${baseUrl}/readyz`, { method: 'POST' });

  assert.equal(response.status, 405);
  assert.equal(response.headers.get('allow'), 'GET');
});

test('unknown routes are not exposed', async () => {
  const response = await fetch(`${baseUrl}/`);

  assert.equal(response.status, 404);
});

test('login creates a seven-day secure, HttpOnly session cookie', async () => {
  const response = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: ' USER@EXAMPLE.COM ', password: 'test-password-123' })
  });
  const cookie = response.headers.get('set-cookie');

  assert.equal(response.status, 200);
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /Secure/);
  assert.match(cookie, /SameSite=Lax/);
  assert.match(cookie, /Max-Age=604800/);
  assert.deepEqual(await response.json(), {
    user: {
      id: '00000000-0000-0000-0000-000000000001',
      full_name: 'Test User',
      divisi: 'Testing',
      jabatan: 'OPERATOR | PELAKSANA'
    }
  });
});

test('login rejects wrong passwords and unverified accounts without revealing which failed', async () => {
  const wrongPassword = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'user@example.com', password: 'wrong-password' })
  });
  authUser.email_verified_at = null;
  const unverified = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'user@example.com', password: 'test-password-123' })
  });
  authUser.email_verified_at = new Date();

  assert.equal(wrongPassword.status, 401);
  assert.deepEqual(await wrongPassword.json(), { error: 'Email or password is incorrect' });
  assert.equal(unverified.status, 401);
  assert.deepEqual(await unverified.json(), { error: 'Email or password is incorrect' });
});

test('session lookup requires a valid session and logout revokes it', async () => {
  const login = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'user@example.com', password: 'test-password-123' })
  });
  const cookie = login.headers.get('set-cookie').split(';')[0];

  const session = await fetch(`${baseUrl}/api/auth/me`, {
    headers: { Cookie: cookie }
  });
  assert.equal(session.status, 200);
  assert.equal((await session.json()).user.id, authUser.profile_id);

  const logout = await fetch(`${baseUrl}/api/auth/logout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookie },
    body: '{}'
  });
  assert.equal(logout.status, 200);
  assert.match(logout.headers.get('set-cookie'), /Max-Age=0/);

  const expiredSession = await fetch(`${baseUrl}/api/auth/me`, {
    headers: { Cookie: cookie }
  });
  assert.equal(expiredSession.status, 401);
});

test('login rejects non-JSON requests and malformed JSON', async () => {
  const wrongContentType = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    body: 'email=user@example.com'
  });
  const malformed = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: 'null'
  });

  assert.equal(wrongContentType.status, 415);
  assert.equal(malformed.status, 400);
});

test('database configuration must be explicit and use a valid port', () => {
  assert.throws(
    () => validateDatabaseEnvironment({}),
    /PGHOST, PGDATABASE, PGUSER, PGPASSWORD/
  );
  assert.throws(
    () => validateDatabaseEnvironment({
      PGHOST: 'localhost',
      PGDATABASE: 'mtc',
      PGUSER: 'mtc_api',
      PGPASSWORD: 'test-only'
    }),
    /PGDATABASE must be mtc_migration_test2/
  );
  assert.deepEqual(
    validateDatabaseEnvironment({
      PGHOST: 'localhost',
      PGDATABASE: 'mtc_migration_test2',
      PGUSER: 'mtc_api',
      PGPASSWORD: 'test-only',
      PGPORT: '5432'
    }),
    { port: 5432 }
  );
  assert.throws(
    () => validateDatabaseEnvironment({
      PGHOST: 'localhost',
      PGDATABASE: 'mtc_migration_test2',
      PGUSER: 'mtc_api',
      PGPASSWORD: 'test-only',
      PGPORT: '70000'
    }),
    /PGPORT/
  );
});
