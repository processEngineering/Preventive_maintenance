# MTC API authentication prototype

This is a Node.js prototype for validating the test-database connection and the
server-side login/session design. It is not connected to the frontend and must not
be exposed to the internet or used for production traffic.

## Requirements

- Node.js 18 or later
- Network access from this machine to the PostgreSQL test database
- A PostgreSQL role created for this connectivity test, with permission to connect
  to `mtc_migration_test2` and read from `public.profiles`

Do not use a PostgreSQL superuser. Do not commit database credentials or place them
in this repository.

## Unit-test locally

From this directory:

```powershell
npm install
npm test
```

The tests use a stub database client and do not connect to PostgreSQL.

## Verify database connectivity on PE-SERVER2

Copy the `backend` directory to PE-SERVER2 using an approved method. Open PowerShell
on PE-SERVER2 and run the following from the copied `backend` directory:

```powershell
npm ci
npm test

$env:PGHOST = '127.0.0.1'
$env:PGPORT = '5432'
$env:PGDATABASE = 'mtc_migration_test2'
$env:PGUSER = Read-Host 'Test-only PostgreSQL username'
$securePassword = Read-Host 'Test-only PostgreSQL password' -AsSecureString
$passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
try {
    $env:PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
}

npm start
```

Use a PostgreSQL test role limited to connecting to `mtc_migration_test2` and
selecting from `public.profiles`; do not use a superuser. If PostgreSQL is not
listening on `127.0.0.1:5432`, use the approved host and port for the test instance.
The app refuses to start if `PGDATABASE` is not exactly `mtc_migration_test2`.

While `npm start` is running, open a second PowerShell window on PE-SERVER2 and run:

```powershell
Invoke-RestMethod http://127.0.0.1:3000/healthz
Invoke-RestMethod http://127.0.0.1:3000/readyz
```

Expect `healthz` to return `status: ok` and `readyz` to return `status: ready` with
`database: connected`. A `503` from `readyz` means the API process is running but
cannot complete its database query; check the local API log and confirm the test
role, database name, host, port, and table permission. Do not paste credentials or
personal data into chat. Stop the API with Ctrl+C in the first window, then clear its
environment variables with:

```powershell
'PGHOST', 'PGPORT', 'PGDATABASE', 'PGUSER', 'PGPASSWORD' | ForEach-Object {
    Remove-Item "Env:$_" -ErrorAction SilentlyContinue
}
Remove-Variable securePassword, passwordPointer -ErrorAction SilentlyContinue
```

## Endpoints

- `GET /healthz` checks that the process is running.
- `GET /readyz` runs only `SELECT 1 FROM public.profiles LIMIT 1` and returns
  `{"status":"ready","database":"connected"}` on success. It returns a generic
  `503` response on connection/query failure and does not return database details.
- `POST /api/auth/login` checks a pre-provisioned, email-verified account and creates
  a seven-day server-side session. Passwords are verified using Node.js scrypt.
- `GET /api/auth/me` checks the session cookie and returns the signed-in profile.
- `POST /api/auth/logout` revokes the server-side session and clears the cookie.

Login uses an `HttpOnly`, `Secure`, `SameSite=Lax` cookie. Only a hash of the random
session token is stored in PostgreSQL. The `jabatan` value is returned as profile
information; it does not grant different API permissions.

## Authentication prototype limitations

- The schema in `sql/001_auth.sql` has not yet been applied to any database.
- Existing Supabase user IDs and emails have not been imported. Keep any account
  export private; do not put it in the repository or send it in chat.
- Signup, email verification, initial password setup, password reset, and email
  delivery are intentionally not implemented until the company approves an email
  sender.
- No login rate limiting or operational feature authorization is implemented.
- The existing frontend still uses Supabase. These endpoints do not replace it yet.
- Do not open an ngrok tunnel or expose this prototype externally.

## Test-database schema and runtime account

Only after review, apply `sql/001_auth.sql` to `mtc_migration_test2` using an
administrator-controlled database session. Do not apply it to production.

The existing `mtc_api_connectivity` role is read-only and is not sufficient for
authentication. Create a separate runtime role and grant only:

- `CONNECT` on `mtc_migration_test2`
- `USAGE` on schema `public`
- `SELECT` on `profiles` and `app_users`
- `SELECT`, `INSERT`, and `DELETE` on `app_sessions`

Do not grant the API role table ownership, schema creation, or access to production.
Do not put credentials in this repository.
